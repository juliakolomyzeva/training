<?php

namespace ix\HangmanBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HangmanBundle extends Bundle
{
}
