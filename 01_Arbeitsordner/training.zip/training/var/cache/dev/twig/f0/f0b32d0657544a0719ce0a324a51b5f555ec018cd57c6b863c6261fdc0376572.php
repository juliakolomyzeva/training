<?php

/* @Hangman/layout.html.twig */
class __TwigTemplate_4d7befb3ef18e9bfb197abc6334556178f85358317eeb6474d4c0e9418926c74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "@Hangman/layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bc589ddc3c923a16e014ad7bde943a08ebd1b9d90173336b694629e0847e6e5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc589ddc3c923a16e014ad7bde943a08ebd1b9d90173336b694629e0847e6e5c->enter($__internal_bc589ddc3c923a16e014ad7bde943a08ebd1b9d90173336b694629e0847e6e5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/layout.html.twig"));

        $__internal_ad1eee2c7e24197f8ca0d495280dc7d89832810356e090a187734f1bc72ed2dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad1eee2c7e24197f8ca0d495280dc7d89832810356e090a187734f1bc72ed2dc->enter($__internal_ad1eee2c7e24197f8ca0d495280dc7d89832810356e090a187734f1bc72ed2dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bc589ddc3c923a16e014ad7bde943a08ebd1b9d90173336b694629e0847e6e5c->leave($__internal_bc589ddc3c923a16e014ad7bde943a08ebd1b9d90173336b694629e0847e6e5c_prof);

        
        $__internal_ad1eee2c7e24197f8ca0d495280dc7d89832810356e090a187734f1bc72ed2dc->leave($__internal_ad1eee2c7e24197f8ca0d495280dc7d89832810356e090a187734f1bc72ed2dc_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_8a7afa169e8dc39c2a64bbb320485d8d498e775718d670ce29f500c1391cfc6d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a7afa169e8dc39c2a64bbb320485d8d498e775718d670ce29f500c1391cfc6d->enter($__internal_8a7afa169e8dc39c2a64bbb320485d8d498e775718d670ce29f500c1391cfc6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e20c050633012e14a9096b871e8331475ad0e6420b0a5b47aa95b6d912a90e50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e20c050633012e14a9096b871e8331475ad0e6420b0a5b47aa95b6d912a90e50->enter($__internal_e20c050633012e14a9096b871e8331475ad0e6420b0a5b47aa95b6d912a90e50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, ("Play - Hangman Game " . $this->renderParentBlock("title", $context, $blocks)), "html", null, true);
        
        $__internal_e20c050633012e14a9096b871e8331475ad0e6420b0a5b47aa95b6d912a90e50->leave($__internal_e20c050633012e14a9096b871e8331475ad0e6420b0a5b47aa95b6d912a90e50_prof);

        
        $__internal_8a7afa169e8dc39c2a64bbb320485d8d498e775718d670ce29f500c1391cfc6d->leave($__internal_8a7afa169e8dc39c2a64bbb320485d8d498e775718d670ce29f500c1391cfc6d_prof);

    }

    // line 14
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_246b82470de9cdd807a00d0318ea241074155594b7a06517e8cb8c4e7f754b9d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_246b82470de9cdd807a00d0318ea241074155594b7a06517e8cb8c4e7f754b9d->enter($__internal_246b82470de9cdd807a00d0318ea241074155594b7a06517e8cb8c4e7f754b9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_b08dcb3a2c1f6d71712ac4316b41ad9805042b32799c5723bc2b1a38446e199c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b08dcb3a2c1f6d71712ac4316b41ad9805042b32799c5723bc2b1a38446e199c->enter($__internal_b08dcb3a2c1f6d71712ac4316b41ad9805042b32799c5723bc2b1a38446e199c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 15
        echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/hangman/css/bootstrap.min.css"), "html", null, true);
        echo "\" />
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/hangman/css/style.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_b08dcb3a2c1f6d71712ac4316b41ad9805042b32799c5723bc2b1a38446e199c->leave($__internal_b08dcb3a2c1f6d71712ac4316b41ad9805042b32799c5723bc2b1a38446e199c_prof);

        
        $__internal_246b82470de9cdd807a00d0318ea241074155594b7a06517e8cb8c4e7f754b9d->leave($__internal_246b82470de9cdd807a00d0318ea241074155594b7a06517e8cb8c4e7f754b9d_prof);

    }

    // line 18
    public function block_body($context, array $blocks = array())
    {
        $__internal_efa73a09a108067bbb5acded4c48a3f297c86f793cba68fa56257f061881aea2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_efa73a09a108067bbb5acded4c48a3f297c86f793cba68fa56257f061881aea2->enter($__internal_efa73a09a108067bbb5acded4c48a3f297c86f793cba68fa56257f061881aea2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_11622f588ab23ea065e24ce2be9970f482f2ebfe34499869b5c3351f9501cbda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11622f588ab23ea065e24ce2be9970f482f2ebfe34499869b5c3351f9501cbda->enter($__internal_11622f588ab23ea065e24ce2be9970f482f2ebfe34499869b5c3351f9501cbda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 19
        echo "<div id=\"wrapper\">
    <div id=\"header\">
        <div id=\"logo\">
            <h1>
                <a href=\"/\">Hangman</a>
            </h1>
        </div>
        <div id=\"menu\">
            <ul>
                <li class=\"first current_page_item\">
                    <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_game");
        echo "\">Game</a>
                </li>
                ";
        // line 31
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 32
            echo "                    <li>
                        <a href=\"";
            // line 33
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_registration");
            echo "\">Register</a>
                    </li>
                    <li>
                        <a href=\"";
            // line 36
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_login");
            echo "\">Login</a>
                    </li>
                ";
        } else {
            // line 39
            echo "                    <li>
                        <a href=\"";
            // line 40
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_contact");
            echo "\">Contact</a>
                    </li>
                ";
        }
        // line 43
        echo "            </ul>
            <br class=\"clearfix\" />
        </div>
    </div>

    <div id=\"page\">
        <div id=\"content\">
            ";
        // line 50
        $this->displayBlock('content', $context, $blocks);
        // line 51
        echo "        </div>
        <div id=\"sidebar\">
            <h3>Last Games</h3>
            <div class=\"date-list\">
                <ul class=\"list date-list\">

                    <li class=\"first\"><span class=\"date\">Jan 13</span> <a href=\"#\">Ultrices quisque molestie</a></li>
                    <li><span class=\"date\">Jan 7</span> <a href=\"#\">Neque dolor eget</a></li>
                    <li><span class=\"date\">Jan 1</span> <a href=\"#\">Sollicitudin interdum</a></li>
                    <li class=\"last\"><span class=\"date\">Dec 26</span> <a href=\"#\">Varius dignissim</a></li>

                </ul>
            </div>
            <h3>Last players</h3>
            <ul>
                <li>user 1</li>
                <li>user 2</li>
                <li>user 3</li>
                <li>user 4</li>
                <li>user 5</li>
            </ul>
        </div>
        <br class=\"clearfix\" />
    </div>
</div>
";
        
        $__internal_11622f588ab23ea065e24ce2be9970f482f2ebfe34499869b5c3351f9501cbda->leave($__internal_11622f588ab23ea065e24ce2be9970f482f2ebfe34499869b5c3351f9501cbda_prof);

        
        $__internal_efa73a09a108067bbb5acded4c48a3f297c86f793cba68fa56257f061881aea2->leave($__internal_efa73a09a108067bbb5acded4c48a3f297c86f793cba68fa56257f061881aea2_prof);

    }

    // line 50
    public function block_content($context, array $blocks = array())
    {
        $__internal_8e6af171324c3f2c6260731ed2c6ca71bb24431fd79f8d78b6dd80c63895df5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e6af171324c3f2c6260731ed2c6ca71bb24431fd79f8d78b6dd80c63895df5f->enter($__internal_8e6af171324c3f2c6260731ed2c6ca71bb24431fd79f8d78b6dd80c63895df5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_d47ef2122e9e186b25423d81509456d8f429dd3e78aadba94e4d447ad5ee0fda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d47ef2122e9e186b25423d81509456d8f429dd3e78aadba94e4d447ad5ee0fda->enter($__internal_d47ef2122e9e186b25423d81509456d8f429dd3e78aadba94e4d447ad5ee0fda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_d47ef2122e9e186b25423d81509456d8f429dd3e78aadba94e4d447ad5ee0fda->leave($__internal_d47ef2122e9e186b25423d81509456d8f429dd3e78aadba94e4d447ad5ee0fda_prof);

        
        $__internal_8e6af171324c3f2c6260731ed2c6ca71bb24431fd79f8d78b6dd80c63895df5f->leave($__internal_8e6af171324c3f2c6260731ed2c6ca71bb24431fd79f8d78b6dd80c63895df5f_prof);

    }

    public function getTemplateName()
    {
        return "@Hangman/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  185 => 50,  150 => 51,  148 => 50,  139 => 43,  133 => 40,  130 => 39,  124 => 36,  118 => 33,  115 => 32,  113 => 31,  108 => 29,  96 => 19,  87 => 18,  75 => 16,  70 => 15,  61 => 14,  43 => 12,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{#<!DOCTYPE html>
<html>
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    <title>Hangman Game</title>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />
    <link rel=\"shortcut icon\" href=\"/favicon.ico\" />
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\" />
</head>
<body>#}
{% block title 'Play - Hangman Game ' ~ parent()%}

{% block stylesheets %}
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('bundles/hangman/css/bootstrap.min.css') }}\" />
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('bundles/hangman/css/style.css') }}\" />
{% endblock %}
{% block body %}
<div id=\"wrapper\">
    <div id=\"header\">
        <div id=\"logo\">
            <h1>
                <a href=\"/\">Hangman</a>
            </h1>
        </div>
        <div id=\"menu\">
            <ul>
                <li class=\"first current_page_item\">
                    <a href=\"{{ path( 'app_game' )}}\">Game</a>
                </li>
                {% if is_granted('IS_AUTHENTICATED_FULLY') %}
                    <li>
                        <a href=\"{{ path('app_registration') }}\">Register</a>
                    </li>
                    <li>
                        <a href=\"{{ path('app_login') }}\">Login</a>
                    </li>
                {% else %}
                    <li>
                        <a href=\"{{ path('app_contact') }}\">Contact</a>
                    </li>
                {% endif %}
            </ul>
            <br class=\"clearfix\" />
        </div>
    </div>

    <div id=\"page\">
        <div id=\"content\">
            {% block content %}{% endblock %}
        </div>
        <div id=\"sidebar\">
            <h3>Last Games</h3>
            <div class=\"date-list\">
                <ul class=\"list date-list\">

                    <li class=\"first\"><span class=\"date\">Jan 13</span> <a href=\"#\">Ultrices quisque molestie</a></li>
                    <li><span class=\"date\">Jan 7</span> <a href=\"#\">Neque dolor eget</a></li>
                    <li><span class=\"date\">Jan 1</span> <a href=\"#\">Sollicitudin interdum</a></li>
                    <li class=\"last\"><span class=\"date\">Dec 26</span> <a href=\"#\">Varius dignissim</a></li>

                </ul>
            </div>
            <h3>Last players</h3>
            <ul>
                <li>user 1</li>
                <li>user 2</li>
                <li>user 3</li>
                <li>user 4</li>
                <li>user 5</li>
            </ul>
        </div>
        <br class=\"clearfix\" />
    </div>
</div>
{% endblock %}
{#
</body>
</html>#}", "@Hangman/layout.html.twig", "/Users/infolox/Desktop/training/src/ix/HangmanBundle/Resources/views/layout.html.twig");
    }
}
