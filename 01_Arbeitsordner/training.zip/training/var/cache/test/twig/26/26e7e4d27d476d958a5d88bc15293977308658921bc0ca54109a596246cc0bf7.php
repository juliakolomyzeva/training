<?php

/* base.html.twig */
class __TwigTemplate_dcbea8fed6ada303a8c0d3a0eb6469c0d7cce1bcd07b46b6602bc0198cd03314 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a9576cb62c0714b9b5d6330e3b7b07c5261f12805f67fcc62302be1c7a2be10 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a9576cb62c0714b9b5d6330e3b7b07c5261f12805f67fcc62302be1c7a2be10->enter($__internal_9a9576cb62c0714b9b5d6330e3b7b07c5261f12805f67fcc62302be1c7a2be10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_da239c681dff8a9841fb668f045a457d410bb9d6e33e82cfce95838a894e1bab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da239c681dff8a9841fb668f045a457d410bb9d6e33e82cfce95838a894e1bab->enter($__internal_da239c681dff8a9841fb668f045a457d410bb9d6e33e82cfce95838a894e1bab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_9a9576cb62c0714b9b5d6330e3b7b07c5261f12805f67fcc62302be1c7a2be10->leave($__internal_9a9576cb62c0714b9b5d6330e3b7b07c5261f12805f67fcc62302be1c7a2be10_prof);

        
        $__internal_da239c681dff8a9841fb668f045a457d410bb9d6e33e82cfce95838a894e1bab->leave($__internal_da239c681dff8a9841fb668f045a457d410bb9d6e33e82cfce95838a894e1bab_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_1b81032fe35c7a68fcee9ca574374b6f16fbde12d640f80db423499e32ebd481 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b81032fe35c7a68fcee9ca574374b6f16fbde12d640f80db423499e32ebd481->enter($__internal_1b81032fe35c7a68fcee9ca574374b6f16fbde12d640f80db423499e32ebd481_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_fe83521307d0f8957ba945b75397e6447f636cde59c1bed08f4b95adc93ff343 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe83521307d0f8957ba945b75397e6447f636cde59c1bed08f4b95adc93ff343->enter($__internal_fe83521307d0f8957ba945b75397e6447f636cde59c1bed08f4b95adc93ff343_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_fe83521307d0f8957ba945b75397e6447f636cde59c1bed08f4b95adc93ff343->leave($__internal_fe83521307d0f8957ba945b75397e6447f636cde59c1bed08f4b95adc93ff343_prof);

        
        $__internal_1b81032fe35c7a68fcee9ca574374b6f16fbde12d640f80db423499e32ebd481->leave($__internal_1b81032fe35c7a68fcee9ca574374b6f16fbde12d640f80db423499e32ebd481_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_fe1109ebf29466be0eb8907a76b1cbc0352a65075b4110ba749ab1c848865f5d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe1109ebf29466be0eb8907a76b1cbc0352a65075b4110ba749ab1c848865f5d->enter($__internal_fe1109ebf29466be0eb8907a76b1cbc0352a65075b4110ba749ab1c848865f5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_38bc00f0fe5778d43186c3f798718d87bdcad6c46da79922c652bbdf007e71bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_38bc00f0fe5778d43186c3f798718d87bdcad6c46da79922c652bbdf007e71bc->enter($__internal_38bc00f0fe5778d43186c3f798718d87bdcad6c46da79922c652bbdf007e71bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_38bc00f0fe5778d43186c3f798718d87bdcad6c46da79922c652bbdf007e71bc->leave($__internal_38bc00f0fe5778d43186c3f798718d87bdcad6c46da79922c652bbdf007e71bc_prof);

        
        $__internal_fe1109ebf29466be0eb8907a76b1cbc0352a65075b4110ba749ab1c848865f5d->leave($__internal_fe1109ebf29466be0eb8907a76b1cbc0352a65075b4110ba749ab1c848865f5d_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_ffd067d424573688b875328d3ad7fae59ce4f4b7106b5947c7644413ebf12e63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ffd067d424573688b875328d3ad7fae59ce4f4b7106b5947c7644413ebf12e63->enter($__internal_ffd067d424573688b875328d3ad7fae59ce4f4b7106b5947c7644413ebf12e63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_be155d8b12bc9d8d0362a1a0b2de5c0c82c6edb8dc65dd08abe45d421b7609bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be155d8b12bc9d8d0362a1a0b2de5c0c82c6edb8dc65dd08abe45d421b7609bc->enter($__internal_be155d8b12bc9d8d0362a1a0b2de5c0c82c6edb8dc65dd08abe45d421b7609bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_be155d8b12bc9d8d0362a1a0b2de5c0c82c6edb8dc65dd08abe45d421b7609bc->leave($__internal_be155d8b12bc9d8d0362a1a0b2de5c0c82c6edb8dc65dd08abe45d421b7609bc_prof);

        
        $__internal_ffd067d424573688b875328d3ad7fae59ce4f4b7106b5947c7644413ebf12e63->leave($__internal_ffd067d424573688b875328d3ad7fae59ce4f4b7106b5947c7644413ebf12e63_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_df4e9b339f714ef20db3ffb6ef5207c5c38cb8fcfc1775b0daa3f7f737e29f87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df4e9b339f714ef20db3ffb6ef5207c5c38cb8fcfc1775b0daa3f7f737e29f87->enter($__internal_df4e9b339f714ef20db3ffb6ef5207c5c38cb8fcfc1775b0daa3f7f737e29f87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_b8d29c021f7958e5f8e045082144a2e123fddb04ffa3265d933993ce6d8dad6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8d29c021f7958e5f8e045082144a2e123fddb04ffa3265d933993ce6d8dad6a->enter($__internal_b8d29c021f7958e5f8e045082144a2e123fddb04ffa3265d933993ce6d8dad6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_b8d29c021f7958e5f8e045082144a2e123fddb04ffa3265d933993ce6d8dad6a->leave($__internal_b8d29c021f7958e5f8e045082144a2e123fddb04ffa3265d933993ce6d8dad6a_prof);

        
        $__internal_df4e9b339f714ef20db3ffb6ef5207c5c38cb8fcfc1775b0daa3f7f737e29f87->leave($__internal_df4e9b339f714ef20db3ffb6ef5207c5c38cb8fcfc1775b0daa3f7f737e29f87_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/Users/infolox/Desktop/training/app/Resources/views/base.html.twig");
    }
}
