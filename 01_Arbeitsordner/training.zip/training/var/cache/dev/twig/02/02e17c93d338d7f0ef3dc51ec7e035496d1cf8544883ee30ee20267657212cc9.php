<?php

/* @Hangman/registration/registration.html.twig */
class __TwigTemplate_9777dce6fa1a50e21da60b01d51391aaef4ff5a59fdb39efbd36151cb4ee5b92 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Hangman/layout.html.twig", "@Hangman/registration/registration.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Hangman/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b80f5c8a94e721e3fc6a1308dc730e9b3d79061c4e904fbda96842dc3d182916 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b80f5c8a94e721e3fc6a1308dc730e9b3d79061c4e904fbda96842dc3d182916->enter($__internal_b80f5c8a94e721e3fc6a1308dc730e9b3d79061c4e904fbda96842dc3d182916_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/registration/registration.html.twig"));

        $__internal_b71a1420c2a061c2651d8876f03fe5d44d9d9dc035132ffd6d78f07dc60e8b50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b71a1420c2a061c2651d8876f03fe5d44d9d9dc035132ffd6d78f07dc60e8b50->enter($__internal_b71a1420c2a061c2651d8876f03fe5d44d9d9dc035132ffd6d78f07dc60e8b50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/registration/registration.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b80f5c8a94e721e3fc6a1308dc730e9b3d79061c4e904fbda96842dc3d182916->leave($__internal_b80f5c8a94e721e3fc6a1308dc730e9b3d79061c4e904fbda96842dc3d182916_prof);

        
        $__internal_b71a1420c2a061c2651d8876f03fe5d44d9d9dc035132ffd6d78f07dc60e8b50->leave($__internal_b71a1420c2a061c2651d8876f03fe5d44d9d9dc035132ffd6d78f07dc60e8b50_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_d235d438b95460b5756876ada05884fd7636e235f2b1b9bb55eb8ab5e04787ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d235d438b95460b5756876ada05884fd7636e235f2b1b9bb55eb8ab5e04787ea->enter($__internal_d235d438b95460b5756876ada05884fd7636e235f2b1b9bb55eb8ab5e04787ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2ade14d57bf6c10eb7b9285dc96ac213700a5784e68def4b200cc2076b2e8d78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2ade14d57bf6c10eb7b9285dc96ac213700a5784e68def4b200cc2076b2e8d78->enter($__internal_2ade14d57bf6c10eb7b9285dc96ac213700a5784e68def4b200cc2076b2e8d78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, ("Register - " . $this->renderParentBlock("title", $context, $blocks)), "html", null, true);
        
        $__internal_2ade14d57bf6c10eb7b9285dc96ac213700a5784e68def4b200cc2076b2e8d78->leave($__internal_2ade14d57bf6c10eb7b9285dc96ac213700a5784e68def4b200cc2076b2e8d78_prof);

        
        $__internal_d235d438b95460b5756876ada05884fd7636e235f2b1b9bb55eb8ab5e04787ea->leave($__internal_d235d438b95460b5756876ada05884fd7636e235f2b1b9bb55eb8ab5e04787ea_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_fb781c3b53b8bf2831548d10972f8dfa49e1b719d0b370e9c99fb6eac4055534 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb781c3b53b8bf2831548d10972f8dfa49e1b719d0b370e9c99fb6eac4055534->enter($__internal_fb781c3b53b8bf2831548d10972f8dfa49e1b719d0b370e9c99fb6eac4055534_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_2241db6d169d99c3d36d7767abd3ed04d98441883410046fe231b901231417fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2241db6d169d99c3d36d7767abd3ed04d98441883410046fe231b901231417fb->enter($__internal_2241db6d169d99c3d36d7767abd3ed04d98441883410046fe231b901231417fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "    <h1>Create Account</h1>
    <form action=\"";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_registration");
        echo "\" method=\"post\" novalidate>
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <button type=\"submit\" class=\"btn btn-success\">Send</button>
    </form>


";
        
        $__internal_2241db6d169d99c3d36d7767abd3ed04d98441883410046fe231b901231417fb->leave($__internal_2241db6d169d99c3d36d7767abd3ed04d98441883410046fe231b901231417fb_prof);

        
        $__internal_fb781c3b53b8bf2831548d10972f8dfa49e1b719d0b370e9c99fb6eac4055534->leave($__internal_fb781c3b53b8bf2831548d10972f8dfa49e1b719d0b370e9c99fb6eac4055534_prof);

    }

    public function getTemplateName()
    {
        return "@Hangman/registration/registration.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 7,  71 => 6,  68 => 5,  59 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@Hangman/layout.html.twig\" %}

{% block title 'Register - ' ~ parent() %}
{% block content %}
    <h1>Create Account</h1>
    <form action=\"{{ path('app_registration') }}\" method=\"post\" novalidate>
        {{ form_widget(form) }}
        <button type=\"submit\" class=\"btn btn-success\">Send</button>
    </form>


{% endblock %}", "@Hangman/registration/registration.html.twig", "/Users/infolox/Desktop/training/src/ix/HangmanBundle/Resources/views/registration/registration.html.twig");
    }
}
