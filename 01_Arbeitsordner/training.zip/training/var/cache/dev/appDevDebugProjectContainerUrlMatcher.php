<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // jm_library_library_index
        if ('/library' === $pathinfo) {
            return array (  '_controller' => 'jm\\LibraryBundle\\Controller\\LibraryController::indexAction',  '_route' => 'jm_library_library_index',);
        }

        // app_contact
        if ('/contact' === $pathinfo) {
            if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                $allow = array_merge($allow, array('GET', 'POST'));
                goto not_app_contact;
            }

            return array (  '_controller' => 'ix\\HangmanBundle\\Controller\\ContactController::indexAction',  '_route' => 'app_contact',);
        }
        not_app_contact:

        // hello
        if (0 === strpos($pathinfo, '/hello') && preg_match('#^/hello(?:/(?P<name>[^/]++))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'hello')), array (  'name' => 'Lindau',  '_controller' => 'ix\\HangmanBundle\\Controller\\DefaultController::indexAction',));
        }

        // app_game
        if (preg_match('#^/(?P<_locale>[^/]++)/game/$#s', $pathinfo, $matches)) {
            if ('GET' !== $canonicalMethod) {
                $allow[] = 'GET';
                goto not_app_game;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_game')), array (  '_controller' => 'ix\\HangmanBundle\\Controller\\GameController::indexAction',));
        }
        not_app_game:

        // reset_game
        if (preg_match('#^/(?P<_locale>[^/]++)/game/reset$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'reset_game')), array (  '_controller' => 'ix\\HangmanBundle\\Controller\\GameController::resetGame',));
        }

        // app_play_word
        if (preg_match('#^/(?P<_locale>[^/]++)/game/word$#s', $pathinfo, $matches)) {
            if ('POST' !== $canonicalMethod) {
                $allow[] = 'POST';
                goto not_app_play_word;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_play_word')), array (  '_controller' => 'ix\\HangmanBundle\\Controller\\GameController::playWordAction',));
        }
        not_app_play_word:

        // app_play_letter
        if (preg_match('#^/(?P<_locale>[^/]++)/game/(?P<letter>[a-zA-Z])$#s', $pathinfo, $matches)) {
            if ('GET' !== $canonicalMethod) {
                $allow[] = 'GET';
                goto not_app_play_letter;
            }

            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_play_letter')), array (  '_controller' => 'ix\\HangmanBundle\\Controller\\GameController::playLetterAction',));
        }
        not_app_play_letter:

        // app_won
        if (preg_match('#^/(?P<_locale>[^/]++)/game/won$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_won')), array (  '_controller' => 'ix\\HangmanBundle\\Controller\\GameController::wonAction',));
        }

        // app_lost
        if (preg_match('#^/(?P<_locale>[^/]++)/game/lost$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_lost')), array (  '_controller' => 'ix\\HangmanBundle\\Controller\\GameController::lostAction',));
        }

        // app_index
        if ('' === $trimmedPathinfo) {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'app_index');
            }

            return array (  '_controller' => 'ix\\HangmanBundle\\Controller\\LanguageController::indexAction',  '_route' => 'app_index',);
        }

        // app_switch_locale
        if (0 === strpos($pathinfo, '/switch') && preg_match('#^/switch/(?P<_locale>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_switch_locale')), array (  '_controller' => 'ix\\HangmanBundle\\Controller\\LanguageController::switchLocaleAction',));
        }

        // app_registration
        if ('/registration' === $pathinfo) {
            if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                $allow = array_merge($allow, array('GET', 'POST'));
                goto not_app_registration;
            }

            return array (  '_controller' => 'ix\\HangmanBundle\\Controller\\SecurityController::registerAction',  '_route' => 'app_registration',);
        }
        not_app_registration:

        // app_login
        if ('/login' === $pathinfo) {
            return array (  '_controller' => 'ix\\HangmanBundle\\Controller\\SecurityController::loginAction',  '_route' => 'app_login',);
        }

        // app_logout
        if ('/logout' === $pathinfo) {
            return array (  '_controller' => 'ix\\HangmanBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'app_logout',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
