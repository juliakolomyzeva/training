<?php

/* @Hangman/game/index.html.twig */
class __TwigTemplate_5b4b30db40e9b08105265a011397b41c8663cd998df74a93011f2c0ae904012e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Hangman/layout.html.twig", "@Hangman/game/index.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Hangman/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20292697e7de388fc1922dbeb2c4bd1fa943ccdf864a60e3221df962c5ee2383 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_20292697e7de388fc1922dbeb2c4bd1fa943ccdf864a60e3221df962c5ee2383->enter($__internal_20292697e7de388fc1922dbeb2c4bd1fa943ccdf864a60e3221df962c5ee2383_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/game/index.html.twig"));

        $__internal_51d2a2728d91524d2d70b237fa2442ab2cc079c22c80587d818bccd74a654148 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51d2a2728d91524d2d70b237fa2442ab2cc079c22c80587d818bccd74a654148->enter($__internal_51d2a2728d91524d2d70b237fa2442ab2cc079c22c80587d818bccd74a654148_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/game/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_20292697e7de388fc1922dbeb2c4bd1fa943ccdf864a60e3221df962c5ee2383->leave($__internal_20292697e7de388fc1922dbeb2c4bd1fa943ccdf864a60e3221df962c5ee2383_prof);

        
        $__internal_51d2a2728d91524d2d70b237fa2442ab2cc079c22c80587d818bccd74a654148->leave($__internal_51d2a2728d91524d2d70b237fa2442ab2cc079c22c80587d818bccd74a654148_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_9aee1aa0fb16dea8ebd174f185162815c4068d82691b3207d9471248f2fc3f9c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9aee1aa0fb16dea8ebd174f185162815c4068d82691b3207d9471248f2fc3f9c->enter($__internal_9aee1aa0fb16dea8ebd174f185162815c4068d82691b3207d9471248f2fc3f9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_e9a2a31023b581eed6f04e80ae95b2c1197e1a3b272acde2d0ccc4c373907e75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9a2a31023b581eed6f04e80ae95b2c1197e1a3b272acde2d0ccc4c373907e75->enter($__internal_e9a2a31023b581eed6f04e80ae95b2c1197e1a3b272acde2d0ccc4c373907e75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "<h2>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("game.play.headline"), "html", null, true);
        echo "</h2>

";
        if ($this->env->isDebug()) {
            // line 5
            \Symfony\Component\VarDumper\VarDumper::dump((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")));
        }
        // line 6
        echo "<p class=\"attempts\">
    ";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->transchoice("game.play.attemps", $this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "remainingAttempts", array())), "html", null, true);
        echo "
</p>

<ul class=\"word_letters\">
    ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "wordLetters", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["letter"]) {
            // line 12
            echo "        ";
            if ($this->getAttribute((isset($context["game"]) ? $context["game"] : $this->getContext($context, "game")), "letterFound", array(0 => $context["letter"]), "method")) {
                // line 13
                echo "
            <li class=\"letter guessed\">
                ";
                // line 15
                echo twig_escape_filter($this->env, $context["letter"], "html", null, true);
                echo "
            </li>
        ";
            } else {
                // line 18
                echo "            <li class=\"letter\">
                ?
            </li>

        ";
            }
            // line 23
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['letter'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "</ul>

<br class=\"clearfix\" />

<p class=\"attempts\">
    <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("reset_game");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("game.reset"), "html", null, true);
        echo "</a>
</p>

<br class=\"clearfix\" />

<h2>";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("game.try_letter"), "html", null, true);
        echo "</h2>

<ul>
    ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range("A", "Z"));
        foreach ($context['_seq'] as $context["_key"] => $context["letter"]) {
            // line 38
            echo "    <li class=\"letter\">
        <a href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_play_letter", array("letter" => $context["letter"])), "html", null, true);
            echo "\">
            ";
            // line 40
            echo twig_escape_filter($this->env, $context["letter"], "html", null, true);
            echo "
        </a>
    </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['letter'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "</ul>


<h2>";
        // line 47
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("game.try_world"), "html", null, true);
        echo "</h2>

<form action=";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_play_word");
        echo " method=\"post\">
    <p>
        <label for=\"word\">Word:</label>
        <input type=\"text\" id=\"word\" name=\"word\"/>
        <button type=\"submit\">Let me guess...</button>
    </p>
</form>
";
        
        $__internal_e9a2a31023b581eed6f04e80ae95b2c1197e1a3b272acde2d0ccc4c373907e75->leave($__internal_e9a2a31023b581eed6f04e80ae95b2c1197e1a3b272acde2d0ccc4c373907e75_prof);

        
        $__internal_9aee1aa0fb16dea8ebd174f185162815c4068d82691b3207d9471248f2fc3f9c->leave($__internal_9aee1aa0fb16dea8ebd174f185162815c4068d82691b3207d9471248f2fc3f9c_prof);

    }

    public function getTemplateName()
    {
        return "@Hangman/game/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 49,  148 => 47,  143 => 44,  133 => 40,  129 => 39,  126 => 38,  122 => 37,  116 => 34,  106 => 29,  99 => 24,  93 => 23,  86 => 18,  80 => 15,  76 => 13,  73 => 12,  69 => 11,  62 => 7,  59 => 6,  56 => 5,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Hangman/layout.html.twig' %}
{% block content %}
<h2>{{ 'game.play.headline'|trans }}</h2>

{% dump(game) %}
<p class=\"attempts\">
    {{ 'game.play.attemps'|transchoice(game.remainingAttempts) }}
</p>

<ul class=\"word_letters\">
    {% for letter in game.wordLetters %}
        {% if game.letterFound(letter) %}

            <li class=\"letter guessed\">
                {{ letter }}
            </li>
        {% else %}
            <li class=\"letter\">
                ?
            </li>

        {% endif %}
    {% endfor %}
</ul>

<br class=\"clearfix\" />

<p class=\"attempts\">
    <a href=\"{{ path('reset_game') }}\">{{ 'game.reset'|trans }}</a>
</p>

<br class=\"clearfix\" />

<h2>{{ 'game.try_letter'|trans }}</h2>

<ul>
    {% for letter in 'A'..'Z' %}
    <li class=\"letter\">
        <a href=\"{{ path('app_play_letter', {letter: letter}) }}\">
            {{ letter }}
        </a>
    </li>
    {% endfor %}
</ul>


<h2>{{ 'game.try_world'|trans }}</h2>

<form action={{ path(\"app_play_word\") }} method=\"post\">
    <p>
        <label for=\"word\">Word:</label>
        <input type=\"text\" id=\"word\" name=\"word\"/>
        <button type=\"submit\">Let me guess...</button>
    </p>
</form>
{% endblock %}", "@Hangman/game/index.html.twig", "/Users/infolox/Desktop/training/src/ix/HangmanBundle/Resources/views/game/index.html.twig");
    }
}
