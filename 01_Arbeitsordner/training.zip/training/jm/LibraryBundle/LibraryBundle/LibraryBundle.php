<?php

namespace LibraryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LibraryBundle extends Bundle
{
}
