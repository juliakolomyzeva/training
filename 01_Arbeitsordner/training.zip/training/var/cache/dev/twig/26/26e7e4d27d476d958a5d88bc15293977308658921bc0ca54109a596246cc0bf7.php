<?php

/* base.html.twig */
class __TwigTemplate_dcbea8fed6ada303a8c0d3a0eb6469c0d7cce1bcd07b46b6602bc0198cd03314 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5183356f620829bc213a1a8fdb7d1b63ed7825b53a97bf08bd4e0cfb64684cab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5183356f620829bc213a1a8fdb7d1b63ed7825b53a97bf08bd4e0cfb64684cab->enter($__internal_5183356f620829bc213a1a8fdb7d1b63ed7825b53a97bf08bd4e0cfb64684cab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_a03013d211d4ce48975f2f2b37ac49620841995c8f755ae02a5223f6365d40ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a03013d211d4ce48975f2f2b37ac49620841995c8f755ae02a5223f6365d40ff->enter($__internal_a03013d211d4ce48975f2f2b37ac49620841995c8f755ae02a5223f6365d40ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_5183356f620829bc213a1a8fdb7d1b63ed7825b53a97bf08bd4e0cfb64684cab->leave($__internal_5183356f620829bc213a1a8fdb7d1b63ed7825b53a97bf08bd4e0cfb64684cab_prof);

        
        $__internal_a03013d211d4ce48975f2f2b37ac49620841995c8f755ae02a5223f6365d40ff->leave($__internal_a03013d211d4ce48975f2f2b37ac49620841995c8f755ae02a5223f6365d40ff_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_b5b06a5f386ff9f2b9943a508b9caa7343288a1f6c222da910fa1fb4fa7e4621 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b5b06a5f386ff9f2b9943a508b9caa7343288a1f6c222da910fa1fb4fa7e4621->enter($__internal_b5b06a5f386ff9f2b9943a508b9caa7343288a1f6c222da910fa1fb4fa7e4621_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_009c4853ca3c91c8a08a22b49a05ab558a05bb585bacb60e13ca8724f464ada7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_009c4853ca3c91c8a08a22b49a05ab558a05bb585bacb60e13ca8724f464ada7->enter($__internal_009c4853ca3c91c8a08a22b49a05ab558a05bb585bacb60e13ca8724f464ada7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_009c4853ca3c91c8a08a22b49a05ab558a05bb585bacb60e13ca8724f464ada7->leave($__internal_009c4853ca3c91c8a08a22b49a05ab558a05bb585bacb60e13ca8724f464ada7_prof);

        
        $__internal_b5b06a5f386ff9f2b9943a508b9caa7343288a1f6c222da910fa1fb4fa7e4621->leave($__internal_b5b06a5f386ff9f2b9943a508b9caa7343288a1f6c222da910fa1fb4fa7e4621_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ebcab7d1a343a7b0769acb2c12f94f0d7caeb5f8cba7d1d26aa873b599827390 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ebcab7d1a343a7b0769acb2c12f94f0d7caeb5f8cba7d1d26aa873b599827390->enter($__internal_ebcab7d1a343a7b0769acb2c12f94f0d7caeb5f8cba7d1d26aa873b599827390_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_e0076bb0fe2096363799a7904cbdaf102d6af647697e55edf1598230ad9c8476 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0076bb0fe2096363799a7904cbdaf102d6af647697e55edf1598230ad9c8476->enter($__internal_e0076bb0fe2096363799a7904cbdaf102d6af647697e55edf1598230ad9c8476_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_e0076bb0fe2096363799a7904cbdaf102d6af647697e55edf1598230ad9c8476->leave($__internal_e0076bb0fe2096363799a7904cbdaf102d6af647697e55edf1598230ad9c8476_prof);

        
        $__internal_ebcab7d1a343a7b0769acb2c12f94f0d7caeb5f8cba7d1d26aa873b599827390->leave($__internal_ebcab7d1a343a7b0769acb2c12f94f0d7caeb5f8cba7d1d26aa873b599827390_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_91321e530900b0e96427df8fe9cd608faa096c90bd1eee70aab2db2bab5cfde1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_91321e530900b0e96427df8fe9cd608faa096c90bd1eee70aab2db2bab5cfde1->enter($__internal_91321e530900b0e96427df8fe9cd608faa096c90bd1eee70aab2db2bab5cfde1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_56a86993c4c361a51354d687c520b8fc93c28cc911eca2f14396a6fd23efb078 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56a86993c4c361a51354d687c520b8fc93c28cc911eca2f14396a6fd23efb078->enter($__internal_56a86993c4c361a51354d687c520b8fc93c28cc911eca2f14396a6fd23efb078_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_56a86993c4c361a51354d687c520b8fc93c28cc911eca2f14396a6fd23efb078->leave($__internal_56a86993c4c361a51354d687c520b8fc93c28cc911eca2f14396a6fd23efb078_prof);

        
        $__internal_91321e530900b0e96427df8fe9cd608faa096c90bd1eee70aab2db2bab5cfde1->leave($__internal_91321e530900b0e96427df8fe9cd608faa096c90bd1eee70aab2db2bab5cfde1_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_238793b1757f2354630af5b384f68d32602f3536cf61af788df08825690cb4a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_238793b1757f2354630af5b384f68d32602f3536cf61af788df08825690cb4a7->enter($__internal_238793b1757f2354630af5b384f68d32602f3536cf61af788df08825690cb4a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_a5cdc917aaa746d68b61060437157d77c609856bf4225b99cd08044c1eed8da9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5cdc917aaa746d68b61060437157d77c609856bf4225b99cd08044c1eed8da9->enter($__internal_a5cdc917aaa746d68b61060437157d77c609856bf4225b99cd08044c1eed8da9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_a5cdc917aaa746d68b61060437157d77c609856bf4225b99cd08044c1eed8da9->leave($__internal_a5cdc917aaa746d68b61060437157d77c609856bf4225b99cd08044c1eed8da9_prof);

        
        $__internal_238793b1757f2354630af5b384f68d32602f3536cf61af788df08825690cb4a7->leave($__internal_238793b1757f2354630af5b384f68d32602f3536cf61af788df08825690cb4a7_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/Users/infolox/Desktop/training/app/Resources/views/base.html.twig");
    }
}
