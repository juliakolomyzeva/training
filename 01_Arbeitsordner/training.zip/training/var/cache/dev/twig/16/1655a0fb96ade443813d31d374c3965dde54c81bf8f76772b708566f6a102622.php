<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_c3f8b0947506950015bc0a722b4d9c126dad6e5462363c1c2e12f8caa82164e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fcfa1ffd3866d476ac9ce863f6eb09618a8f6641fea248cc31a3a43325aac4f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fcfa1ffd3866d476ac9ce863f6eb09618a8f6641fea248cc31a3a43325aac4f0->enter($__internal_fcfa1ffd3866d476ac9ce863f6eb09618a8f6641fea248cc31a3a43325aac4f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_31554b5e3e3a5636296c1788fe2e9e174d8e431cb171bbb835dc37a9952331bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31554b5e3e3a5636296c1788fe2e9e174d8e431cb171bbb835dc37a9952331bf->enter($__internal_31554b5e3e3a5636296c1788fe2e9e174d8e431cb171bbb835dc37a9952331bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_fcfa1ffd3866d476ac9ce863f6eb09618a8f6641fea248cc31a3a43325aac4f0->leave($__internal_fcfa1ffd3866d476ac9ce863f6eb09618a8f6641fea248cc31a3a43325aac4f0_prof);

        
        $__internal_31554b5e3e3a5636296c1788fe2e9e174d8e431cb171bbb835dc37a9952331bf->leave($__internal_31554b5e3e3a5636296c1788fe2e9e174d8e431cb171bbb835dc37a9952331bf_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "/Users/infolox/Desktop/training/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/chevron-right.svg");
    }
}
