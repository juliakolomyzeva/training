<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_3ba7a2aad6189688ad7334a28ad9f743bfa309de6207b0983bb01983acc3dd28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4a0ccefbe4c324480b3319284cb9a7e83ae4f4d27e4403d3872826931af38b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b4a0ccefbe4c324480b3319284cb9a7e83ae4f4d27e4403d3872826931af38b4->enter($__internal_b4a0ccefbe4c324480b3319284cb9a7e83ae4f4d27e4403d3872826931af38b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_fc275ac53966fcef46f6d2616c041d406fb9eb66f8d97e2d87370801ff9ff73f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc275ac53966fcef46f6d2616c041d406fb9eb66f8d97e2d87370801ff9ff73f->enter($__internal_fc275ac53966fcef46f6d2616c041d406fb9eb66f8d97e2d87370801ff9ff73f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b4a0ccefbe4c324480b3319284cb9a7e83ae4f4d27e4403d3872826931af38b4->leave($__internal_b4a0ccefbe4c324480b3319284cb9a7e83ae4f4d27e4403d3872826931af38b4_prof);

        
        $__internal_fc275ac53966fcef46f6d2616c041d406fb9eb66f8d97e2d87370801ff9ff73f->leave($__internal_fc275ac53966fcef46f6d2616c041d406fb9eb66f8d97e2d87370801ff9ff73f_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_32a65969fbe5da9b557e01265748428552300841c0ea20c0c5229c690ecdb1fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32a65969fbe5da9b557e01265748428552300841c0ea20c0c5229c690ecdb1fc->enter($__internal_32a65969fbe5da9b557e01265748428552300841c0ea20c0c5229c690ecdb1fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_3e20f4e2be38b7590df2da4693f659ca0a6bffac0986f4ce68365ff34e88cc12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e20f4e2be38b7590df2da4693f659ca0a6bffac0986f4ce68365ff34e88cc12->enter($__internal_3e20f4e2be38b7590df2da4693f659ca0a6bffac0986f4ce68365ff34e88cc12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_3e20f4e2be38b7590df2da4693f659ca0a6bffac0986f4ce68365ff34e88cc12->leave($__internal_3e20f4e2be38b7590df2da4693f659ca0a6bffac0986f4ce68365ff34e88cc12_prof);

        
        $__internal_32a65969fbe5da9b557e01265748428552300841c0ea20c0c5229c690ecdb1fc->leave($__internal_32a65969fbe5da9b557e01265748428552300841c0ea20c0c5229c690ecdb1fc_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b471bc65d06eaa1d1aea3913f7503dc7995a7e54f2c10d723538f7386f05a4a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b471bc65d06eaa1d1aea3913f7503dc7995a7e54f2c10d723538f7386f05a4a4->enter($__internal_b471bc65d06eaa1d1aea3913f7503dc7995a7e54f2c10d723538f7386f05a4a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e67c3071364a150c0f3d3af78f55652b8e597264d3dae56c9e3af0040d81d14e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e67c3071364a150c0f3d3af78f55652b8e597264d3dae56c9e3af0040d81d14e->enter($__internal_e67c3071364a150c0f3d3af78f55652b8e597264d3dae56c9e3af0040d81d14e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_e67c3071364a150c0f3d3af78f55652b8e597264d3dae56c9e3af0040d81d14e->leave($__internal_e67c3071364a150c0f3d3af78f55652b8e597264d3dae56c9e3af0040d81d14e_prof);

        
        $__internal_b471bc65d06eaa1d1aea3913f7503dc7995a7e54f2c10d723538f7386f05a4a4->leave($__internal_b471bc65d06eaa1d1aea3913f7503dc7995a7e54f2c10d723538f7386f05a4a4_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d3b0a0a4477bd871d2f0608e89b60cbff48e095a0bd088f90846911618688bc4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3b0a0a4477bd871d2f0608e89b60cbff48e095a0bd088f90846911618688bc4->enter($__internal_d3b0a0a4477bd871d2f0608e89b60cbff48e095a0bd088f90846911618688bc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_95203236e2b9f4e3f7c330590cad3b46b7343e11af15b7669a969aa5f362be2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95203236e2b9f4e3f7c330590cad3b46b7343e11af15b7669a969aa5f362be2d->enter($__internal_95203236e2b9f4e3f7c330590cad3b46b7343e11af15b7669a969aa5f362be2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_95203236e2b9f4e3f7c330590cad3b46b7343e11af15b7669a969aa5f362be2d->leave($__internal_95203236e2b9f4e3f7c330590cad3b46b7343e11af15b7669a969aa5f362be2d_prof);

        
        $__internal_d3b0a0a4477bd871d2f0608e89b60cbff48e095a0bd088f90846911618688bc4->leave($__internal_d3b0a0a4477bd871d2f0608e89b60cbff48e095a0bd088f90846911618688bc4_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/infolox/Desktop/training/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
