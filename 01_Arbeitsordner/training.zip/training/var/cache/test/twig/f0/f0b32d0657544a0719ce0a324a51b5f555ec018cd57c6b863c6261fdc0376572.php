<?php

/* @Hangman/layout.html.twig */
class __TwigTemplate_4d7befb3ef18e9bfb197abc6334556178f85358317eeb6474d4c0e9418926c74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "@Hangman/layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff9fef40285e7c090dd052fe7aa33e7e6324fe075baef84b9510501a1bec6a80 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff9fef40285e7c090dd052fe7aa33e7e6324fe075baef84b9510501a1bec6a80->enter($__internal_ff9fef40285e7c090dd052fe7aa33e7e6324fe075baef84b9510501a1bec6a80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/layout.html.twig"));

        $__internal_6d51e43ea45d77a86b6a7f21a17869447f9a8374af0923d11344bfdfd021104f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d51e43ea45d77a86b6a7f21a17869447f9a8374af0923d11344bfdfd021104f->enter($__internal_6d51e43ea45d77a86b6a7f21a17869447f9a8374af0923d11344bfdfd021104f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ff9fef40285e7c090dd052fe7aa33e7e6324fe075baef84b9510501a1bec6a80->leave($__internal_ff9fef40285e7c090dd052fe7aa33e7e6324fe075baef84b9510501a1bec6a80_prof);

        
        $__internal_6d51e43ea45d77a86b6a7f21a17869447f9a8374af0923d11344bfdfd021104f->leave($__internal_6d51e43ea45d77a86b6a7f21a17869447f9a8374af0923d11344bfdfd021104f_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_dd48e8b95d42726655ffddd6085919a1a1d767bccde20247656bde851d676923 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd48e8b95d42726655ffddd6085919a1a1d767bccde20247656bde851d676923->enter($__internal_dd48e8b95d42726655ffddd6085919a1a1d767bccde20247656bde851d676923_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_d2c04ae4a8a75ca253e55d62f0669c977c94f04d459e375b70b1bb34d26d1560 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2c04ae4a8a75ca253e55d62f0669c977c94f04d459e375b70b1bb34d26d1560->enter($__internal_d2c04ae4a8a75ca253e55d62f0669c977c94f04d459e375b70b1bb34d26d1560_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, ("Play - Hangman Game " . $this->renderParentBlock("title", $context, $blocks)), "html", null, true);
        
        $__internal_d2c04ae4a8a75ca253e55d62f0669c977c94f04d459e375b70b1bb34d26d1560->leave($__internal_d2c04ae4a8a75ca253e55d62f0669c977c94f04d459e375b70b1bb34d26d1560_prof);

        
        $__internal_dd48e8b95d42726655ffddd6085919a1a1d767bccde20247656bde851d676923->leave($__internal_dd48e8b95d42726655ffddd6085919a1a1d767bccde20247656bde851d676923_prof);

    }

    // line 14
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_30667374d3d5ac3486492d95d2ccbc279b2bded758b5896705d5240c26f2fac5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30667374d3d5ac3486492d95d2ccbc279b2bded758b5896705d5240c26f2fac5->enter($__internal_30667374d3d5ac3486492d95d2ccbc279b2bded758b5896705d5240c26f2fac5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_64ef6018125a583ac95ee1dceed8272fc88cffeb6af2bb63673bc57cc1b2b76a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64ef6018125a583ac95ee1dceed8272fc88cffeb6af2bb63673bc57cc1b2b76a->enter($__internal_64ef6018125a583ac95ee1dceed8272fc88cffeb6af2bb63673bc57cc1b2b76a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 15
        echo "    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/hangman/css/bootstrap.min.css"), "html", null, true);
        echo "\" />
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/hangman/css/style.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_64ef6018125a583ac95ee1dceed8272fc88cffeb6af2bb63673bc57cc1b2b76a->leave($__internal_64ef6018125a583ac95ee1dceed8272fc88cffeb6af2bb63673bc57cc1b2b76a_prof);

        
        $__internal_30667374d3d5ac3486492d95d2ccbc279b2bded758b5896705d5240c26f2fac5->leave($__internal_30667374d3d5ac3486492d95d2ccbc279b2bded758b5896705d5240c26f2fac5_prof);

    }

    // line 18
    public function block_body($context, array $blocks = array())
    {
        $__internal_b8f578ad05aa99a5ffc78d30ff06ed8f86e9c5614ce1c9db70b4cca2d0f30674 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8f578ad05aa99a5ffc78d30ff06ed8f86e9c5614ce1c9db70b4cca2d0f30674->enter($__internal_b8f578ad05aa99a5ffc78d30ff06ed8f86e9c5614ce1c9db70b4cca2d0f30674_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8a0b9228af6e65b578e3e0f4d19198873c7eb518e3581c9970f3ca0e39101c59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a0b9228af6e65b578e3e0f4d19198873c7eb518e3581c9970f3ca0e39101c59->enter($__internal_8a0b9228af6e65b578e3e0f4d19198873c7eb518e3581c9970f3ca0e39101c59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 19
        echo "<div id=\"wrapper\">
    <div id=\"header\">
        <div id=\"logo\">
            <h1>
                <a href=\"/\">Hangman</a>
            </h1>
        </div>
        <div id=\"menu\">
            <ul>
                <li class=\"first current_page_item\">
                    <a href=\"/en/game/\">Game</a>
                </li>
                <li>
                    <a href=\"/signup\">Register</a>
                </li>
                <li>
                    <a href=\"/signin\">Login</a>
                </li>
                <li>
                    <a href=\"/contact\">Contact</a>
                </li>
            </ul>
            <br class=\"clearfix\" />
        </div>
    </div>

    <div id=\"page\">
        <div id=\"content\">
            ";
        // line 47
        $this->displayBlock('content', $context, $blocks);
        // line 48
        echo "        </div>
        <div id=\"sidebar\">
            <h3>Last Games</h3>
            <div class=\"date-list\">
                <ul class=\"list date-list\">

                    <li class=\"first\"><span class=\"date\">Jan 13</span> <a href=\"#\">Ultrices quisque molestie</a></li>
                    <li><span class=\"date\">Jan 7</span> <a href=\"#\">Neque dolor eget</a></li>
                    <li><span class=\"date\">Jan 1</span> <a href=\"#\">Sollicitudin interdum</a></li>
                    <li class=\"last\"><span class=\"date\">Dec 26</span> <a href=\"#\">Varius dignissim</a></li>

                </ul>
            </div>
            <h3>Last players</h3>
            <ul>
                <li>user 1</li>
                <li>user 2</li>
                <li>user 3</li>
                <li>user 4</li>
                <li>user 5</li>
            </ul>
        </div>
        <br class=\"clearfix\" />
    </div>
</div>
";
        
        $__internal_8a0b9228af6e65b578e3e0f4d19198873c7eb518e3581c9970f3ca0e39101c59->leave($__internal_8a0b9228af6e65b578e3e0f4d19198873c7eb518e3581c9970f3ca0e39101c59_prof);

        
        $__internal_b8f578ad05aa99a5ffc78d30ff06ed8f86e9c5614ce1c9db70b4cca2d0f30674->leave($__internal_b8f578ad05aa99a5ffc78d30ff06ed8f86e9c5614ce1c9db70b4cca2d0f30674_prof);

    }

    // line 47
    public function block_content($context, array $blocks = array())
    {
        $__internal_57b1327cbc116bcc5f1376e8b1fb7c33b54b1d4126a055c0b4d076da0f2078b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_57b1327cbc116bcc5f1376e8b1fb7c33b54b1d4126a055c0b4d076da0f2078b3->enter($__internal_57b1327cbc116bcc5f1376e8b1fb7c33b54b1d4126a055c0b4d076da0f2078b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_aa47f01dfb877ef8cfdf612f19f39e526545ebc43921210a43006bd162f60571 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa47f01dfb877ef8cfdf612f19f39e526545ebc43921210a43006bd162f60571->enter($__internal_aa47f01dfb877ef8cfdf612f19f39e526545ebc43921210a43006bd162f60571_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_aa47f01dfb877ef8cfdf612f19f39e526545ebc43921210a43006bd162f60571->leave($__internal_aa47f01dfb877ef8cfdf612f19f39e526545ebc43921210a43006bd162f60571_prof);

        
        $__internal_57b1327cbc116bcc5f1376e8b1fb7c33b54b1d4126a055c0b4d076da0f2078b3->leave($__internal_57b1327cbc116bcc5f1376e8b1fb7c33b54b1d4126a055c0b4d076da0f2078b3_prof);

    }

    public function getTemplateName()
    {
        return "@Hangman/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 47,  128 => 48,  126 => 47,  96 => 19,  87 => 18,  75 => 16,  70 => 15,  61 => 14,  43 => 12,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{#<!DOCTYPE html>
<html>
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    <title>Hangman Game</title>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" />
    <link rel=\"shortcut icon\" href=\"/favicon.ico\" />
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\" />
</head>
<body>#}
{% block title 'Play - Hangman Game ' ~ parent()%}

{% block stylesheets %}
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('bundles/hangman/css/bootstrap.min.css') }}\" />
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('bundles/hangman/css/style.css') }}\" />
{% endblock %}
{% block body %}
<div id=\"wrapper\">
    <div id=\"header\">
        <div id=\"logo\">
            <h1>
                <a href=\"/\">Hangman</a>
            </h1>
        </div>
        <div id=\"menu\">
            <ul>
                <li class=\"first current_page_item\">
                    <a href=\"/en/game/\">Game</a>
                </li>
                <li>
                    <a href=\"/signup\">Register</a>
                </li>
                <li>
                    <a href=\"/signin\">Login</a>
                </li>
                <li>
                    <a href=\"/contact\">Contact</a>
                </li>
            </ul>
            <br class=\"clearfix\" />
        </div>
    </div>

    <div id=\"page\">
        <div id=\"content\">
            {% block content %}{% endblock %}
        </div>
        <div id=\"sidebar\">
            <h3>Last Games</h3>
            <div class=\"date-list\">
                <ul class=\"list date-list\">

                    <li class=\"first\"><span class=\"date\">Jan 13</span> <a href=\"#\">Ultrices quisque molestie</a></li>
                    <li><span class=\"date\">Jan 7</span> <a href=\"#\">Neque dolor eget</a></li>
                    <li><span class=\"date\">Jan 1</span> <a href=\"#\">Sollicitudin interdum</a></li>
                    <li class=\"last\"><span class=\"date\">Dec 26</span> <a href=\"#\">Varius dignissim</a></li>

                </ul>
            </div>
            <h3>Last players</h3>
            <ul>
                <li>user 1</li>
                <li>user 2</li>
                <li>user 3</li>
                <li>user 4</li>
                <li>user 5</li>
            </ul>
        </div>
        <br class=\"clearfix\" />
    </div>
</div>
{% endblock %}
{#
</body>
</html>#}", "@Hangman/layout.html.twig", "/Users/infolox/Desktop/training/src/ix/HangmanBundle/Resources/views/layout.html.twig");
    }
}
