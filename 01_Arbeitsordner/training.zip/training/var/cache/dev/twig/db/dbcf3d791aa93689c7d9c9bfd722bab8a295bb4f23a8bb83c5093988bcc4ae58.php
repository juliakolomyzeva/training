<?php

/* @Hangman/security/login.html.twig */
class __TwigTemplate_fbbf873690dfe6abe3ba8df8a2c6e7478c83599ee7d98a6b62504a72cc76f3a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Hangman/layout.html.twig", "@Hangman/security/login.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Hangman/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_33651c046993ab80a515795cf60e177299abfd43357858185bc671b69730c21a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_33651c046993ab80a515795cf60e177299abfd43357858185bc671b69730c21a->enter($__internal_33651c046993ab80a515795cf60e177299abfd43357858185bc671b69730c21a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/security/login.html.twig"));

        $__internal_b28926474dfb9407838f1b5540779e61a8431ea1f5289fdec0d2dc33e2b7d56c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b28926474dfb9407838f1b5540779e61a8431ea1f5289fdec0d2dc33e2b7d56c->enter($__internal_b28926474dfb9407838f1b5540779e61a8431ea1f5289fdec0d2dc33e2b7d56c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Hangman/security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_33651c046993ab80a515795cf60e177299abfd43357858185bc671b69730c21a->leave($__internal_33651c046993ab80a515795cf60e177299abfd43357858185bc671b69730c21a_prof);

        
        $__internal_b28926474dfb9407838f1b5540779e61a8431ea1f5289fdec0d2dc33e2b7d56c->leave($__internal_b28926474dfb9407838f1b5540779e61a8431ea1f5289fdec0d2dc33e2b7d56c_prof);

    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        $__internal_fd661f6812e5af5308f6af5b8284108a37377690bb02794addb9ca45f4f3b640 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd661f6812e5af5308f6af5b8284108a37377690bb02794addb9ca45f4f3b640->enter($__internal_fd661f6812e5af5308f6af5b8284108a37377690bb02794addb9ca45f4f3b640_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_3796aa601ee5c6e6d49410a225138a3a1d1eab870b9a1dbd5504b7a5302b4a37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3796aa601ee5c6e6d49410a225138a3a1d1eab870b9a1dbd5504b7a5302b4a37->enter($__internal_3796aa601ee5c6e6d49410a225138a3a1d1eab870b9a1dbd5504b7a5302b4a37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 5
        echo "    <h2>Sign in</h2>
    ";
        // line 6
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 7
            echo "        ";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\DumpExtension')->dump($this->env, $context, (isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")));
            echo "
    ";
        }
        // line 9
        echo "    <form action=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_login");
        echo "\" method=\"post\" novalidate>
        <div>
            <label for=\"email\">Email</label>
            <input type=\"email\" name=\"email\" id=\"email\"/>
        </div>
        <div>
            <label for=\"password\">Password</label>
            <input type=\"password\" name=\"password\" id=\"password\"/>
        </div>
        <button type=\"submit\">Login</button>
    </form>


";
        
        $__internal_3796aa601ee5c6e6d49410a225138a3a1d1eab870b9a1dbd5504b7a5302b4a37->leave($__internal_3796aa601ee5c6e6d49410a225138a3a1d1eab870b9a1dbd5504b7a5302b4a37_prof);

        
        $__internal_fd661f6812e5af5308f6af5b8284108a37377690bb02794addb9ca45f4f3b640->leave($__internal_fd661f6812e5af5308f6af5b8284108a37377690bb02794addb9ca45f4f3b640_prof);

    }

    // line 24
    public function block_title($context, array $blocks = array())
    {
        $__internal_a6a5aca6d1d3610804a511e922b529ba58157a4d83d17f0fad03ab0cdaa4439d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a6a5aca6d1d3610804a511e922b529ba58157a4d83d17f0fad03ab0cdaa4439d->enter($__internal_a6a5aca6d1d3610804a511e922b529ba58157a4d83d17f0fad03ab0cdaa4439d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_19688a38dece35802e843607f0271edd61be2804ece47ebb4fc1a9503d571b55 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19688a38dece35802e843607f0271edd61be2804ece47ebb4fc1a9503d571b55->enter($__internal_19688a38dece35802e843607f0271edd61be2804ece47ebb4fc1a9503d571b55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 25
        echo "    Sign in
";
        
        $__internal_19688a38dece35802e843607f0271edd61be2804ece47ebb4fc1a9503d571b55->leave($__internal_19688a38dece35802e843607f0271edd61be2804ece47ebb4fc1a9503d571b55_prof);

        
        $__internal_a6a5aca6d1d3610804a511e922b529ba58157a4d83d17f0fad03ab0cdaa4439d->leave($__internal_a6a5aca6d1d3610804a511e922b529ba58157a4d83d17f0fad03ab0cdaa4439d_prof);

    }

    public function getTemplateName()
    {
        return "@Hangman/security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 25,  86 => 24,  61 => 9,  55 => 7,  53 => 6,  50 => 5,  41 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"@Hangman/layout.html.twig\" %}


{% block content %}
    <h2>Sign in</h2>
    {% if error %}
        {{ dump(error) }}
    {% endif %}
    <form action=\"{{ path('app_login') }}\" method=\"post\" novalidate>
        <div>
            <label for=\"email\">Email</label>
            <input type=\"email\" name=\"email\" id=\"email\"/>
        </div>
        <div>
            <label for=\"password\">Password</label>
            <input type=\"password\" name=\"password\" id=\"password\"/>
        </div>
        <button type=\"submit\">Login</button>
    </form>


{% endblock %}

{% block title %}
    Sign in
{% endblock %}", "@Hangman/security/login.html.twig", "/Users/infolox/Desktop/training/src/ix/HangmanBundle/Resources/views/security/login.html.twig");
    }
}
