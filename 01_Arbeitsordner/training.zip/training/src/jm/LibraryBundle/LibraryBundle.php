<?php
/**
 * Created by PhpStorm.
 * User: infolox
 * Date: 03.07.17
 * Time: 22:45
 */

namespace jm\LibraryBundle;


use Symfony\Component\HttpKernel\Bundle\Bundle;

class LibraryBundle extends Bundle
{

}